# JeJeMaMa Skwela Website

A responsive, school-themed Jejemon-style static website for moms.

## Replace the PNG images

Keep the same filenames inside `assets/images/`:

- `school-logo.png` — website logo / favicon
- `hero-mama.png` — main hero image
- `mama-1.png`, `mama-2.png`, `mama-3.png` — mama profile cards
- `gallery-1.png` to `gallery-5.png` — gallery photos

Recommended image sizes:

- Hero: 1200 × 1400 px, transparent PNG or portrait photo
- Mama cards: 900 × 1000 px
- Gallery: at least 1200 × 900 px
- Logo: 512 × 512 px

## Edit website content

Open `index.html` in any text editor and replace the sample Bisaya/Jejemon text.
Colors and layout are in `css/style.css`. Animations and gallery lightbox are in `js/script.js`.

## Preview locally

Double-click `index.html`, or use VS Code Live Server.

## Deploy

### Netlify
Drag the entire `jeje-mama-school-site` folder into Netlify Drop.

### GitHub Pages
Upload all files to a GitHub repository, then enable Pages in repository settings.

### Vercel
Import the folder/repository as a static project. No build command is required.
