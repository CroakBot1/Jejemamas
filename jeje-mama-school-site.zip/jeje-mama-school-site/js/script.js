const menuButton = document.querySelector('.menu-button');
const nav = document.querySelector('.main-nav');
const navLinks = [...document.querySelectorAll('.main-nav a')];

menuButton?.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', String(open));
});

navLinks.forEach((link) => {
  link.addEventListener('click', () => {
    nav.classList.remove('open');
    menuButton?.setAttribute('aria-expanded', 'false');
  });
});

const sectionObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (!entry.isIntersecting) return;
    const current = navLinks.find((link) => link.getAttribute('href') === `#${entry.target.id}`);
    navLinks.forEach((link) => link.classList.remove('active'));
    current?.classList.add('active');
  });
}, { rootMargin: '-40% 0px -50% 0px', threshold: 0 });

document.querySelectorAll('main section[id]').forEach((section) => sectionObserver.observe(section));

const revealTargets = document.querySelectorAll('.mama-card, .schedule-board, .gallery-item, .sticky-note, .cta-card');
revealTargets.forEach((target) => target.classList.add('reveal'));

const revealObserver = new IntersectionObserver((entries, observer) => {
  entries.forEach((entry) => {
    if (!entry.isIntersecting) return;
    entry.target.classList.add('visible');
    observer.unobserve(entry.target);
  });
}, { threshold: 0.12 });

revealTargets.forEach((target) => revealObserver.observe(target));

const countTargets = document.querySelectorAll('[data-count]');
let countsStarted = false;

const countObserver = new IntersectionObserver((entries) => {
  if (countsStarted || !entries.some((entry) => entry.isIntersecting)) return;
  countsStarted = true;

  countTargets.forEach((target) => {
    const end = Number(target.dataset.count || 0);
    const startTime = performance.now();
    const duration = 900;

    const tick = (now) => {
      const progress = Math.min((now - startTime) / duration, 1);
      target.textContent = Math.round(end * progress);
      if (progress < 1) requestAnimationFrame(tick);
    };

    requestAnimationFrame(tick);
  });
}, { threshold: 0.5 });

const stats = document.querySelector('.mini-stats');
if (stats) countObserver.observe(stats);

const tiltCard = document.querySelector('.tilt-card');
if (tiltCard && matchMedia('(pointer:fine)').matches) {
  tiltCard.addEventListener('mousemove', (event) => {
    const rect = tiltCard.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - 0.5;
    const y = (event.clientY - rect.top) / rect.height - 0.5;
    tiltCard.style.transform = `perspective(900px) rotateX(${(-y * 6).toFixed(2)}deg) rotateY(${(x * 7).toFixed(2)}deg) rotateZ(2deg)`;
  });

  tiltCard.addEventListener('mouseleave', () => {
    tiltCard.style.transform = 'perspective(900px) rotateX(0deg) rotateY(0deg) rotateZ(2deg)';
  });
}

const lightbox = document.querySelector('.lightbox');
const lightboxImage = lightbox?.querySelector('img');
const lightboxCaption = lightbox?.querySelector('p');
const lightboxClose = lightbox?.querySelector('.lightbox-close');

if (lightbox && lightboxImage && lightboxCaption) {
  document.querySelectorAll('.gallery-item').forEach((item) => {
    item.addEventListener('click', () => {
      const image = item.querySelector('img');
      if (!image) return;
      lightboxImage.src = image.src;
      lightboxImage.alt = image.alt;
      lightboxCaption.textContent = item.dataset.caption || image.alt;
      lightbox.showModal();
    });
  });

  lightboxClose?.addEventListener('click', () => lightbox.close());
  lightbox.addEventListener('click', (event) => {
    if (event.target === lightbox) lightbox.close();
  });
}

document.getElementById('year').textContent = new Date().getFullYear();
